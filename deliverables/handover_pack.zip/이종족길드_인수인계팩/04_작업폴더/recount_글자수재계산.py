import re,sys
p=sys.argv[1]; L=open(p).read().split('\n'); out=[]; over=[]
i=0
def content_from(k):
    buf=[]
    while k<len(L) and not (L[k].startswith('■') or L[k].startswith('━')): buf.append(L[k]); k+=1
    return '\n'.join(buf).strip('\n')
res=[]
for idx,line in enumerate(L):
    m=re.search(r'\((\d+)/(\d+)\)',line)
    if not m or not (line.startswith('■') or line.startswith('[1]') or line.startswith('설명') or line.startswith('프롬프트')): continue
    k=idx+1
    if line.startswith('[1]'): k+=1
    if line.startswith('■ 노트'):
        while not L[k].startswith('내용:'): k+=1
        k+=1
    c=content_from(k); n=len(c); lim=int(m.group(2))
    L[idx]=line[:m.start()]+f'({n}/{lim})'+line[m.end():]
    res.append((line[:30],n,lim))
    if n>lim: over.append((line[:40],n,lim))
open(p,'w').write('\n'.join(L))
for r in res[:6]: print(r)
print('OVER:',over)
